package com.northcoders.RecordShopApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlbumShopApiApplicationTests {

	@Test
	void contextLoads() {


	}

}
