package com.northcoders.RecordShopApi.Exception;

public class InvalidAlbumException extends RuntimeException {
    public InvalidAlbumException(String message) {
        super(message);
    }
}
